
int countInputFile(){
    // TO DO: parse the input file and count the number of lines in the input file
    // does fgets into the input file (ex file_1.txt and counts number of lines in input file
    // should be read from input_files and given the input file line count for the array size
    int size = 3; // dummy value for testing
    return size; 
}